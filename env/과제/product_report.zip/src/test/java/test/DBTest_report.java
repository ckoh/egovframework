package test;

import java.util.Iterator;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import product.ProductDao;
import product.ProductService;
import product.ProductVO;
import user.service.UserService;
import user.vo.UserVO;

public class DBTest_report {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
		ProductService productService = (ProductService) applicationContext.getBean("product_service");
		
		ProductVO productVO = new ProductVO();
		productVO.setPcode("java");
		productVO.setPdesc("java");
		productVO.setPname("java");
		productVO.setPrice(100);
		productVO.setQuant(100);
		productService.insertRow(productVO);
		
		productService.updateRow(productVO);
		
		productService.getRow(productVO);
		
		List<ProductVO> list = productService.getGrid();
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			System.out.println((ProductVO) iterator.next());
		}
		
		productService.deleteRow(productVO);
		
	}
}
