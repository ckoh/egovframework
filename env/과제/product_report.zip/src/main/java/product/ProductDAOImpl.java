package product;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

// @Component("mybatis")
@Component("product_mybatis")
public class ProductDAOImpl implements ProductDao{
	
	@Autowired
	SqlSession sqlSession;
	
	@Override
	public List<ProductVO> getGrid() {
		System.out.println("getGrid ProductDAOImpl");
		return sqlSession.selectList("product.getGrid");
	}
	
	@Override
	public ProductVO getRow(ProductVO productVO) {
		System.out.println("getRow ProductDAOImpl");
		return sqlSession.selectOne("product.getRow", productVO);
	}
	
	@Override
	public int updateRow(ProductVO productVO) {
		System.out.println("updateRow ProductDAOImpl");
		return sqlSession.update("product.updateRow", productVO);
	}

	@Override
	public int insertRow(ProductVO productVO) {
		System.out.println("insertRow ProductDAOImpl");
		return sqlSession.update("product.insertRow", productVO);
	}

	@Override
	public int deleteRow(ProductVO productVO) {
		System.out.println("deleteRow ProductDAOImpl");
		return sqlSession.update("product.deleteRow", productVO);
	}
}
