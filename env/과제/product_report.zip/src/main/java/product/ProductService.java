package product;

import java.util.List;

public interface ProductService {
	public List<ProductVO> getGrid();
	public ProductVO getRow(ProductVO productVO);
	public int updateRow(ProductVO productVO);
	public int insertRow(ProductVO productVO);
	public int deleteRow(ProductVO productVO);
}
