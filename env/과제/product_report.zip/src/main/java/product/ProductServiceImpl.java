package product;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

@Service("product_service")
public class ProductServiceImpl implements ProductService{
	
	 @Resource(name="product_mybatis")
	ProductDAOImpl dao;
	
	@Override
	public List<ProductVO> getGrid() {
		return dao.getGrid();
	}

	@Override
	public ProductVO getRow(ProductVO productVO) {
		return dao.getRow(productVO);
	}

	@Override
	public int updateRow(ProductVO productVO) {
		return dao.updateRow(productVO);
	}

	@Override
	public int insertRow(ProductVO productVO) {
		return dao.insertRow(productVO);
	}

	@Override
	public int deleteRow(ProductVO productVO) {
		return dao.deleteRow(productVO);
	}

}
