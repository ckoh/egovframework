package product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;

	/**
	 * 리스트화면
	 * 
	 * @return
	 */
	@RequestMapping(value = "/list.do")
	public ModelAndView getGrid() {

		System.out.println("getGrid ProductController");

		ModelAndView view = new ModelAndView();

		System.out.println(productService.getGrid());

		view.addObject("products", productService.getGrid());
		view.setViewName("product_list");

		return view;
	}

	/**
	 * 등록
	 * 
	 * @return
	 */
	@RequestMapping(value = "/add.do")
	public ModelAndView getAdd(ProductVO productVO) {

		System.out.println("getAdd ProductController : " + productVO);

		ModelAndView view = new ModelAndView();

		if (productVO.getPcode() == null) {
			view.setViewName("product_form");
		} else {
			productService.insertRow(productVO);
			view.setViewName("redirect:/list.do");
		}

		return view;
	}
	
	/**
	 * 수정화면
	 * @param productVO
	 * @return
	 */
	@RequestMapping(value="/view.do")
	public ModelAndView getRow(ProductVO productVO) {
		System.out.println("getRow ProductController : " + productVO);

		ModelAndView view = new ModelAndView();
		ProductVO row = productService.getRow(productVO);
		
		view.addObject("product", row);
		view.setViewName("product_modify");
		
		return view;
	}
	
	@RequestMapping(value="/update.do")
	public ModelAndView updateRow(ProductVO productVO) {
		System.out.println("updateRow ProductController : " + productVO);

		ModelAndView view = new ModelAndView();
		productService.updateRow(productVO);
		
		view.addObject("product", productVO);
		view.setViewName("product_modify");
		
		return view;
	}
	
	/*
	@RequestMapping(value="/delete.do")
	public ModelAndView deleteRow(ProductVO productVO){
		
		System.out.println("deleteRow ProductController : " + productVO);
		ModelAndView view = new ModelAndView();
		
		productService.deleteRow(productVO);
		
		view.setViewName("");
		
		return view;
	}*/
	
}