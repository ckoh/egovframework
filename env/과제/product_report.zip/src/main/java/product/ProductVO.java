package product;

public class ProductVO {
	
	/**
	 * create table products (
		pcode   varchar2(10) constraint products_pk primary key,
		pname   varchar2(30),
		price   number(8),
		quant   number(5),
		pdesc  varchar2(200)
		);
	 */
	
	private String pcode;
	private String pname;
	private int price;
	private int quant;
	private String pdesc;
	
	public String getPcode() {
		return pcode;
	}
	public void setPcode(String pcode) {
		this.pcode = pcode;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuant() {
		return quant;
	}
	public void setQuant(int quant) {
		this.quant = quant;
	}
	public String getPdesc() {
		return pdesc;
	}
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	@Override
	public String toString() {
		return "ProductVO [pcode=" + pcode + ", pname=" + pname + ", price=" + price + ", quant=" + quant + ", pdesc=" + pdesc + "]";
	}
	
}
