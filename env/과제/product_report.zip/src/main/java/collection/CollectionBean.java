package collection;

import java.util.List;

public class CollectionBean {
	
	private List<String> addr;

	public List<String> getAddr() {
		return addr;
	}

	public void setAddr(List<String> addr) {
		this.addr = addr;
	}
}
