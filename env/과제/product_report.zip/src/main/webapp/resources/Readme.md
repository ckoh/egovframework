# ext-theme-crisp-aad78fd0-688f-48e6-b88b-35c539a2a904/resources

This folder contains static resources (typically an `"images"` folder as well).
