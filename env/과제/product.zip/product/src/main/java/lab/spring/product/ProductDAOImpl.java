package lab.spring.product;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("productDAOImpl")
public class ProductDAOImpl {	 
		
	    @Autowired
		private SqlSession sqlSession;
	    
	    public int add(Product p) {
			return sqlSession.insert("lab.spring.mapper.userMapper.add", p);
		}
		
		public Product getProduct(String uid){
			Product p = null;
			p =  sqlSession.selectOne("lab.spring.mapper.userMapper.view", uid);
			return p;
		}
		public int updateProduct(Product p) {
			return sqlSession.update("lab.spring.mapper.userMapper.update", p);
		}
		
		public List<Product> getProductList(){
			List<Product> users = new ArrayList<Product>();
			users =  sqlSession.selectList("lab.spring.mapper.userMapper.list");
			return users;
		}
		public int deleteProduct(String p){
			return sqlSession.delete("lab.spring.mapper.userMapper.delete", p);
		}
		
		
	}






