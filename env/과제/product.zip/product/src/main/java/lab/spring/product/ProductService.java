package lab.spring.product;

import java.util.List;

public interface ProductService {
   public int addProduct(Product p);
   public Product getProduct(String pcode);
   public List<Product> getProductList();
   public int updateProduct(Product p);
   public int deleteProduct(String pcode);
}
