package lab.spring.controller;

import java.util.ArrayList;
import java.util.List;

import lab.spring.product.Product;
import lab.spring.product.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {
    @Autowired
	private ProductService service1;
	
	@RequestMapping("/list.do") 
	public ModelAndView getProductList(){
		    List<Product> list = new ArrayList<Product>();
		    ModelAndView mav = new ModelAndView();

		    list = service1.getProductList();

		    mav.setViewName("product_list");  
		    mav.addObject("products", list);  
		    return mav;
	}
	
	@RequestMapping(value="/add.do", method=RequestMethod.GET)
	public String addUserForm(){
		return "product_form";
	}
	
	@RequestMapping(value="/add.do", method=RequestMethod.POST)
	public ModelAndView addUserProc(Product p){//
	     ModelAndView mav = new ModelAndView();

		 if(service1.addProduct(p) > 0){
		    	mav.setViewName("redirect:/list.do");
		 }else{
		    	mav.setViewName("error");
		 }
		 return mav;
	}
	@RequestMapping(value="/view.do")
	public ModelAndView view(@RequestParam("pcode") String pcode){//
	     ModelAndView mav = new ModelAndView();
         Product vo = null;
         vo = service1.getProduct(pcode);
		 if(vo != null){
			    mav.addObject("product",vo);
		    	mav.setViewName("product_view");
		 }else{
		    	mav.setViewName("error");
		 }
		 return mav;
	}
	
	
	@RequestMapping(value="/modify.do")
	public ModelAndView editProductProc(String pcode){
	     ModelAndView mav = new ModelAndView();
	     Product vo = null;
	     System.out.println("수정 키값 : "+pcode);
	     vo = service1.getProduct(pcode);
		 if(vo != null){
			    mav.addObject("product",vo);
		    	mav.setViewName("product_modify");
		 }else{
		    	mav.setViewName("error");
		 }
		 return mav;
	}
	@RequestMapping(value="/update.do")
	public ModelAndView updateUserProc(Product vo){
	     ModelAndView mav = new ModelAndView();

		 if(service1.updateProduct(vo) > 0){
		    	mav.setViewName("redirect:/list.do");
		    	
		 }else{
		    	mav.setViewName("error");
		 }
		 return mav;
	}
	
	@RequestMapping(value="/delete.do")
	public ModelAndView removeUserProc(@RequestParam("pcode") String pcode){
		System.out.println("삭제 키 : "+pcode);
	     ModelAndView mav = new ModelAndView();
	     if(service1.deleteProduct(pcode) > 0){
		    	mav.setViewName("redirect:/list.do");
		 }else{
		    	mav.setViewName("error");
		 }
		 return mav;
	}
	
	
	
	
}

















