package lab.spring.product;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("userService")
public class ProductServiceImpl implements ProductService{
	@Autowired
	@Qualifier("productDAOImpl")
	private ProductDAOImpl  dao;
	
	public void setDao(ProductDAOImpl dao){
		this.dao = dao;
	}	
	
	@Override
	public int addProduct(Product p) {
		return dao.add(p);
	}
	@Override
	public Product getProduct(String pcode) {
		return dao.getProduct(pcode);
	}
	@Override
	public List<Product> getProductList() {
		List<Product> list = new ArrayList<Product>();
		list = dao.getProductList();		
		return list;
	}

	@Override
	public int updateProduct(Product p) {
		return dao.updateProduct(p);
	}
	@Override
	public int deleteProduct(String pcode) {
		return dao.deleteProduct(pcode);
	}
}








